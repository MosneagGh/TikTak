package TikTak;

import java.util.Scanner;

public class TikTak {
    static char[][] tabla = new char[3][3];

    public static void init() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) {
                tabla[i][j] = '-';

            }
    }

    public static void start() {

        System.out.println("Sa incepem jocul:");
        System.out.println("Jucatorul Nr.1. Care este numele tau ?");
        String name1 = new Scanner(System.in).nextLine();
        System.out.println("Jucatorul Nr.2. Care este numele tau ?");
        String name2 = new Scanner(System.in).nextLine();

        boolean player1 = true;

        boolean Finish = false;
        while (!Finish) {
            DesTabla(tabla);
            if (player1) {
                System.out.println(name1 + " va merge cu x");
            } else {
                System.out.println(name2 + " va merge cu o");
            }
            char c;
            if (player1) {
                c = 'x';
            } else {
                c = 'o';
            }
            int row;
            int col;

            while (true) {

                System.out.print("Introduce nr. randului (1, 2, 3): ");
                row = new Scanner(System.in).nextInt();
                row -= 1;
                System.out.print("Indroduce nr. coloanei (1, 2, 3): ");
                col = new Scanner(System.in).nextInt();
                col -= 1;

                if (row < 0 || col < 0 || row > 2 || col > 2) {
                    System.out.println("Această poziție este în afara tablei.Incearca din nou !");

                } else if (tabla[row][col] != '-') {
                    System.out.println("Pozitie ocupata. Incerca din nou !");

                } else {
                    break;
                }

            }

            tabla[row][col] = c;

            if (Castig(tabla) == 'x') {
                System.out.println(name1 + " a castigat!");
                Finish = true;
            } else if (Castig(tabla) == 'o') {
                System.out.println(name2 + " a castigat!");
                Finish = true;
            } else {

                if (TablaPlina(tabla)) {
                    System.out.println("Egaliatate!");
                    Finish = true;
                } else {

                    player1 = !player1;
                }

            }

        }
    }

    public static boolean TablaPlina(char[][] board) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == '-') {
                    return false;
                }
            }
        }
        return true;
    }

    public static char Castig(char[][] board) {

        for (int i = 0; i < 3; i++) {
            if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != '-') {
                return board[i][0];
            }
        }

        for (int j = 0; j < 3; j++) {
            if (board[0][j] == board[1][j] && board[1][j] == board[2][j] && board[0][j] != '-') {
                return board[0][j];
            }
        }

        if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != '-') {
            return board[0][0];
        }
        if (board[2][0] == board[1][1] && board[1][1] == board[0][2] && board[2][0] != '-') {
            return board[2][0];
        }

        return ' ';
    }

    public static void DesTabla(char[][] board) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }
}
