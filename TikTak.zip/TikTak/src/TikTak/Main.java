package TikTak;

import static TikTak.TikTak.*;

public class Main  {
    public static void main(String[] args) {
        init();
        start();
        DesTabla(tabla);
        Castig(tabla);
        TablaPlina(tabla);
    }

}
